#!/bin/sh

svn status | grep "?" | xargs rm -rf     
