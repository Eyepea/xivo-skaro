#!/bin/sh

 ./asyhdlc_api -i wp1_chdlc -c wanpipe1 -r -rxcnt 10 -w -txsize 10 -txcnt 9 -verbose
