#!/bin/sh

nice -n -20 ./tdm_hdlc_test.sh "1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16"
#nice -n -20 ./tdm_hdlc_test.sh "1 2  4 5 6 7 8 9 10  12 13 14 15 16"
#./tdm_hdlc_test.sh "1 2  9 10 "
