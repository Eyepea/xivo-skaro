#!/bin/sh


rm -f tmp_cfg/*
