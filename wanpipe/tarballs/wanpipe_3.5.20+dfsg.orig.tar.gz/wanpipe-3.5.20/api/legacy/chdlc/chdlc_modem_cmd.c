/*****************************************************************************
* chdlc_modem_cmd.c	CHDLC API: Modem CMD Example
*
* Author(s):	Nenad Corbic <ncorbic@sangoma.com>
*
* Copyright:	(c) 1995-2008 Sangoma Technologies Inc.
*
*		This program is free software; you can redistribute it and/or
*		modify it under the terms of the GNU General Public License
*		as published by the Free Software Foundation; either version
*		2 of the License, or (at your option) any later version.
* ============================================================================
* Description:
*
* 	The chdlc_api.c utility will bind to a socket to a chdlc network
* 	interface, and continously tx and rx packets to an from the sockets.
*
*	This example has been written for a single interface in mind, 
*	where the same process handles tx and rx data.
*
*	A real world example, should use different processes to handle
*	tx and rx spearately.  
*/



#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <linux/if_wanpipe.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <linux/wanpipe.h>
#include <linux/sdla_chdlc.h>
#include "lib_api.h"

#define FALSE	0
#define TRUE	1

#define LGTH_CRC_BYTES	2
#define MAX_TX_DATA     5000	/* Size of tx data */  
#define MAX_RX_DATA 	MAX_TX_DATA


FILE *tx_fd=NULL,*rx_fd=NULL;	
wan_mbox_t gmbox;


/*===================================================
 * Golobal data
 *==================================================*/

unsigned short no_CRC_bytes_Rx;
unsigned char HDLC_streaming = FALSE;
unsigned short Rx_lgth;

unsigned char Rx_data[MAX_RX_DATA];
unsigned char Tx_data[MAX_TX_DATA];
int 	sock;


/*=================================================== 
 * Function Prototypes 
 *==================================================*/
int MakeConnection(void);
void handle_socket( void);


/*===================================================
 * MakeConnection
 *
 *   o Create a Socket
 *   o Bind a socket to a wanpipe network interface
 *       (Interface name is supplied by the user)
 *==================================================*/         

int MakeConnection(void) 
{
	struct wan_sockaddr_ll 	sa;

	memset(&sa,0,sizeof(struct wan_sockaddr_ll));
	errno = 0;
   	sock = socket(AF_WANPIPE, SOCK_RAW, 0);
   	if( sock < 0 ) {
      		perror("Socket");
      		return(FALSE);
   	} /* if */
  
	printf("\nConnecting to router %s, interface %s\n", card_name, if_name);

	strcpy( (char*)sa.sll_device, if_name);
	strcpy( (char*)sa.sll_card, card_name);
	sa.sll_protocol = htons(PVC_PROT);
	sa.sll_family=AF_WANPIPE;

        if(bind(sock, (struct sockaddr *)&sa, sizeof(struct wan_sockaddr_ll)) < 0){
                perror("bind");
		printf("Failed to bind a socket to %s interface\n",if_name);
                exit(0);
        }
	printf("Socket bound to %s\n\n",if_name);

	return(TRUE);

}


static int exec_cmd(int fd,  wan_mbox_t * mb)
{
	int err = ioctl(sock,SIOC_MBOX_CMD,mb);
	if (err) {
		perror("SIOC_MBOX_CMD");
		return -1;
	}
	
	switch (mb->wan_return_code) {

	case 0:
		return 0;
	default:
		printf("Error: CMD returned 0x%0X\n",
			mb->wan_return_code);
		return -1;
	}

	return 0;
}

static unsigned char gstatus=0;
static int exec_read_modem_cmd(int fd, wan_mbox_t * mb)
{
	MODEM_STATUS_STRUCT *mstat;
	int err=0;
	memset(mb,0,sizeof(wan_mbox_t));
	
	mb->wan_data_len = 0;
	mb->wan_command = READ_MODEM_STATUS;

	err=exec_cmd(fd,mb);
	if (err) {
		return err;
	}
	mstat=(MODEM_STATUS_STRUCT*)mb->wan_data;

	if (mstat->modem_status == gstatus) {
		return 0;
	}
	gstatus = mstat->modem_status;

	printf("MODEM CMD rc=0x%02X  data_len=%i data=0x%02X\n",
		mb->wan_return_code, mb->wan_data_len, mb->wan_data[0]);

	mstat=(MODEM_STATUS_STRUCT*)mb->wan_data;
	
	printf("MODEM STATUS (Data=0x%02X) DCD=%i CTS=%i\n",
		mstat->modem_status,
		(mstat->modem_status&MODEM_DCD_MASK)?1:0,
		(mstat->modem_status&MODEM_CTS_MASK)?1:0);

	return 0;
}

static int exec_set_modem_cmd(int fd, wan_mbox_t * mb, int dtr, int rts)
{
	MODEM_STATUS_STRUCT *mstat=(MODEM_STATUS_STRUCT*)mb->wan_data;

	int err=0;
	memset(mb,0,sizeof(wan_mbox_t));
	
	mb->wan_data_len = 0;
	mb->wan_command = SET_MODEM_STATUS;
	mb->wan_data_len = 1;
	
	mstat->modem_status = 0;
	if (dtr) {
		mstat->modem_status |= SET_MODEM_DTR_HIGH;
	}
	if (rts) {
		mstat->modem_status |= SET_MODEM_RTS_HIGH;
	}


	err=exec_cmd(fd,mb);
	if (err) {
		return err;
	}

	printf("MODEM CMD rc=0x%02X  data_len=%i data=0x%02X (dtr=%i rts=%i)\n",
		mb->wan_return_code, mb->wan_data_len, mb->wan_data[0],dtr,rts);


	return 0;
}



/*===========================================================
 * handle_socket 
 *
 *   o Tx/Rx data to and from the socket 
 *   o Cast received data to an api_rx_element_t data type 
 *   o The received packet contains 16 bytes header 
 *
 *	------------------------------------------
 *      |  16 bytes      |        X bytes        ...
 *	------------------------------------------
 * 	   Header              Data
 *
 * RX DATA:
 * --------
 * 	Each rx data packet contains the 16 byte header!
 * 	
 *   	o Rx 16 byte data structure:
 *
 *		typedef struct {
 *       	 	unsigned char   error_flag      PACKED;
 *        		unsigned short  time_stamp      PACKED;
 *        		unsigned char   reserved[13]    PACKED;
 *		} api_rx_hdr_t; 
 *
 *		typedef struct {
 *        		api_rx_hdr_t    api_rx_hdr      PACKED;
 *        		void *          data            PACKED;
 *		} api_rx_element_t;
 *
 * 	error_flag:
 * 		bit 0: 	incoming frame was aborted
 * 		bit 1: 	incoming frame has a CRC error
 * 		bit 2:  incoming frame has an overrun eror 
 *
 * 	time_stamp:
 * 		absolute time value in ms.
 *
 * TX_DATA:
 * --------
 *	Each tx data packet MUST contain a 16 byte header!
 *
 * 	o Tx 16 byte data structure
 * 	
 *		typedef struct {
 *			unsigned char 	attr		PACKED;
 *			unsigned char  	reserved[15]	PACKED;
 *		} api_tx_hdr_t;
 *
 *		typedef struct {
 *			api_tx_hdr_t 	api_tx_hdr	PACKED;
 *			void *		data		PACKED;
 *		} api_tx_element_t;
 *
 *	Currently the chdlc device driver doesn't use any of
 *	the above fields.  Thus, the user can set the 16 bytes
 *	to ZERO.
 * 
 */

void handle_socket(void) 
{
	unsigned int Rx_count,Tx_count,Tx_length;
	api_rx_element_t* api_rx_el;
	api_tx_element_t * api_tx_el;
	fd_set 	ready,write,oob;
	int err,i;
	int rlen;
	int ferr;
	int txfile_bytes=0;
	void *pRx_data,*pTx_data;
	int no_CRC_bytes_Rx = LGTH_CRC_BYTES;


	pRx_data = (void*)&Rx_data[sizeof(api_rx_hdr_t)];
	pTx_data = (void*)&Tx_data[sizeof(api_tx_hdr_t)]; 

        Rx_count = 0;
	Tx_count = 0;
	Tx_length = tx_size;

	printf("\n\nSocket Handler: Rx=%d Tx=%i TxCnt=%i TxLen=%i TxDelay=%i RxCnt=%i\n",
			read_enable,write_enable,tx_cnt,tx_size,tx_delay,rx_cnt);	
	
	/* If running HDLC_STREAMING then the received CRC bytes
         * will be passed to the application as part of the 
         * received data.  
	 */

	memset(&Tx_data[0],0,MAX_TX_DATA);

	if (files_used & RX_FILE_USED){
		rx_fd=fopen(rx_file,"wb");
		if (!rx_fd){
			printf("Failed to open file %s\n",rx_file);
			perror("File: ");
			return;
		}
		printf("Opening %s rx file\n",rx_file);
	}

	
	if (files_used & TX_FILE_USED){

		tx_fd=fopen(tx_file,"rb");
		if (!tx_fd){
			printf("Failed to open file %s\n",tx_file);
			perror("File: ");
			return;
		}

		printf("Opening %s tx file\n",tx_file);
		
		rlen=fread(pTx_data,
			   sizeof(char),
			   Tx_length,tx_fd);

		
		if (!rlen){
			printf("%s: File empty!\n",
				tx_file);
			return;
		}
	}else{
		api_tx_el = (api_tx_element_t*)&Tx_data[0];

		for (i=0;i<Tx_length;i++){
			if (tx_data == -1){
				api_tx_el->data[i] = (unsigned char)i;
			}else{
				api_tx_el->data[i] = (unsigned char)tx_data;
			}
		}
	}

	if (!write_enable) {
		while (1) {
			exec_read_modem_cmd(sock, &gmbox);
			sleep(1);
		}
	}


	sleep(4);
	exec_set_modem_cmd(sock, &gmbox, 0, 0);
	sleep(4);
	exec_set_modem_cmd(sock, &gmbox, 1, 0);
	sleep(4);
	exec_set_modem_cmd(sock, &gmbox, 0, 1);
	sleep(4);
	exec_set_modem_cmd(sock, &gmbox, 1, 1);
	sleep(4);

	exit(1);


	for(;;) {	
		FD_ZERO(&ready);
		FD_ZERO(&write);
		FD_ZERO(&oob);
		FD_SET(sock,&oob);
		FD_SET(sock,&ready);

		if (write_enable){
		     FD_SET(sock,&write);
		}

		fflush(stdout);
  		if(select(sock + 1,&ready, &write, &oob, NULL)){
	
		   	if (FD_ISSET(sock,&oob)){
		
				err = recv(sock, Rx_data, MAX_RX_DATA, MSG_OOB);

				if(err < 0 ) {
					printf("Failed to receive OOB %i , %i\n", Rx_count, err);
					err = ioctl(sock,SIOC_WANPIPE_SOCK_STATE,0);
					printf("Sock state is %s\n",
							(err == 0) ? "CONNECTED" : 
							(err == 1) ? "DISCONNECTED" :
							 "CONNECTING");
					break;
				}
					
				printf("Got OOB exception: Link Down !\n");
				break;
			}
		  
			
                   	if (FD_ISSET(sock,&ready)){

				err = recv(sock, Rx_data, MAX_RX_DATA, 0);

				if (!read_enable){
					goto bitstrm_skip_read;
				}
				
				/* err indicates bytes received */
				if (err > 0){

					api_rx_el = (api_rx_element_t*)&Rx_data[0];

		                	/* Check the packet length */
                                	Rx_lgth = err - sizeof(api_rx_hdr_t)-no_CRC_bytes_Rx;
                                	if(Rx_lgth<=0) {
                                        	printf("\nShort frame received (%d)\n",
                                                	Rx_lgth);
                                        	return;
					}

					switch (api_rx_el->wp_api_el_operation_status){
				
					case 0:
						/* Rx packet is good */
						break;
						
					case RX_FRM_ABORT:
						/* Frame was aborted */
						break;
					case RX_FRM_CRC_ERROR:
						/* Frame has crc error */
						break;
					case RX_FRM_OVERRUN_ERROR:
						/* Frame has an overrun error */
						break;
					default:
						/* Error with the rx packet 
						 * handle it ... */
						break;
					}

					

					if ((files_used & RX_FILE_USED) && rx_fd){
						ferr=fwrite(pRx_data,
						       	    sizeof(char),
						            Rx_lgth,
						            rx_fd);	
						if (ferr != Rx_lgth){
							printf("Error: fwrite failed: written=%i should have %i\n",
									ferr,Rx_lgth);
						}
					}
				
					++Rx_count;

					if (verbose){
						printf("Received %i Olen=%i Length = %i\n", 
								Rx_count, err,Rx_lgth);
					}else{
						putchar('R');
					}
#if 1	
					if (verbose){
						printf("Data: ");
						for(i=0;(i<Rx_lgth)&&(i<32); i ++) {
							printf("0x%02X ", api_rx_el->data[i]);
						} 
						printf("\n");
					}
#endif
			
					if (rx_cnt == Rx_count){
						printf("Rxcnt %i == RxCount=%i\n",rx_cnt,Rx_count);
						break;
					}

				} else {
					printf("\nError receiving data\n");
					break;
				}

		   	}
		
bitstrm_skip_read:
		   	if (FD_ISSET(sock,&write)){

				err = send(sock,Tx_data, Tx_length + sizeof(api_tx_hdr_t), 0);

				if (err <= 0){
					if (errno == EBUSY){
						if (verbose){
							printf("Sock busy try again!\n");
						}
						/* Socket busy try sending again !*/
					}else{
				 		/* Check socket state */
						err = ioctl(sock,SIOC_WANPIPE_SOCK_STATE,0);
						printf("Sock state is %s\n",
							(err == 0) ? "CONNECTED" : 
							(err == 1) ? "DISCONNECTED" :
							 "CONNECTING");

						printf("Failed to send %i \n",errno);
						perror("Send: ");
						break;
					}
				}else{

					++Tx_count;
					
					if (verbose){
						printf("Packet sent: Sent %i : %i\n",
							err,Tx_count);
					}else{
						//putchar('T');
					}
					txfile_bytes+=Tx_length;

					if ((files_used & TX_FILE_USED) && tx_fd){
						rlen=fread(pTx_data,
							   sizeof(char),
							   Tx_length,tx_fd);

						if (!rlen){
							printf("\nTx of file %s is done %i bytes!\n",
								tx_file,txfile_bytes);	
							break;	
						}
						if (Tx_length != rlen){
							Tx_length = rlen;
						}
					}
				}
		   	}

			if (tx_delay){
				sleep(tx_delay);
			}

			if (tx_size && Tx_count == tx_cnt && !(files_used & TX_FILE_USED)){
				write_enable=0;
				if (!rx_cnt){
					break;
				}
			}
		}
	}

	if (tx_fd){
		fclose(tx_fd);
	}
	if (rx_fd){
		fclose(rx_fd);
	}

	close (sock);
} 

/***************************************************************
 * Main:
 *
 *    o Make a socket connection to the driver.
 *    o Call handle_socket() to read/write the socket 
 *
 **************************************************************/


int main(int argc, char* argv[])
{
	int proceed;

	proceed=init_args(argc,argv);
	if (proceed != WAN_TRUE){
		usage(argv[0]);
		return -1;
	}

	proceed = MakeConnection();
	if(proceed == WAN_TRUE){
		handle_socket();
		return 0;
	}

	return 1;
};
